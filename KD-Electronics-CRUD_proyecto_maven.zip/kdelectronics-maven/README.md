# KD-Electronics – Sistema de Gestión de Inventario CRUD

> **Taller:** Creando un CRUD con JDBC y Programación Orientada a Objetos  
> **Curso:** Programación Orientada a Objetos – UNIMINUTO  

---

## Requisitos previos

- Java 11 o superior  
- Maven 3.6+ (NetBeans y Eclipse lo incluyen)  
- MySQL 8.x  

---

## Pasos para ejecutar

### 1. Crear la base de datos

Abre MySQL Workbench (o la terminal de MySQL) y ejecuta:

```bash
source sql/crear_base_datos.sql
```

### 2. Configurar la conexión

Edita el archivo `src/main/resources/config.properties`:

```properties
db.url=jdbc:mysql://localhost:3306/kdelectronics?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
db.usuario=root
db.clave=TuContraseñaAquí
```

### 3. Importar en NetBeans

1. Archivo → Abrir proyecto → seleccionar la carpeta `KD-Electronics-CRUD`
2. NetBeans detecta automáticamente el `pom.xml` y descarga el conector MySQL
3. Clic derecho en el proyecto → **Limpiar y construir**
4. Clic derecho en `Main.java` → **Ejecutar archivo**

### 4. Importar en Eclipse

1. File → Import → Maven → Existing Maven Projects
2. Seleccionar la carpeta `KD-Electronics-CRUD`
3. Eclipse descarga las dependencias automáticamente
4. Clic derecho en `Main.java` → Run As → Java Application

---

## Estructura del proyecto

```
KD-Electronics-CRUD/
├── pom.xml                          ← Dependencia MySQL, sin descargar JAR manual
├── sql/
│   └── crear_base_datos.sql         ← Ejecutar primero en MySQL
└── src/main/
    ├── java/com/kdelectronics/
    │   ├── model/Producto.java       ← Entidad con soft-delete
    │   ├── db/ConexionBD.java        ← Conexión JDBC (Singleton)
    │   ├── dao/ProductoDAO.java      ← Interfaz CRUD
    │   ├── dao/ProductoDAOImpl.java  ← Implementación con PreparedStatement
    │   ├── util/Validaciones.java    ← Regex para validar campos
    │   └── main/Main.java            ← Punto de entrada y demostración
    └── resources/
        └── config.properties         ← ← ← EDITAR usuario y contraseña aquí
```
