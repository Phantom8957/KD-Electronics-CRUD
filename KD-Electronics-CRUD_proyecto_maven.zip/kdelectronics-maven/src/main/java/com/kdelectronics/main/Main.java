package com.kdelectronics.main;

import com.kdelectronics.dao.ProductoDAO;
import com.kdelectronics.dao.ProductoDAOImpl;
import com.kdelectronics.db.ConexionBD;
import com.kdelectronics.model.Producto;

import java.sql.SQLException;
import java.util.List;

/**
 * Clase principal que demuestra el funcionamiento del CRUD
 * del sistema de gestión de inventario de KD-Electronics.
 *
 * Cubre las cuatro operaciones fundamentales:
 *   C - Create  → crearProducto()
 *   R - Read    → buscarPorCodigo() / listarProductosActivos()
 *   U - Update  → actualizarProducto()
 *   D - Delete  → eliminarProducto() [eliminación lógica]
 *
 * @author [Nombre del Estudiante]
 * @version 1.0
 */
public class Main {

    public static void main(String[] args) {

        ProductoDAO dao = new ProductoDAOImpl();

        System.out.println("╔══════════════════════════════════════════════╗");
        System.out.println("      SISTEMA DE INVENTARIO - KD-Electronics     ");
        System.out.println("╚══════════════════════════════════════════════╝\n");

        // ── 1. CREATE ─────────────────────────────────────────────────────────
        System.out.println("═══ 1. CREAR PRODUCTOS ═══");

        Producto[] productosNuevos = {
            new Producto("ELEC-001", "Smart TV Samsung 55\"",
                "Televisor QLED 55 pulgadas 4K Ultra HD con Smart TV integrado",
                1_200_000.0, 1_599_900.0, "Televisores", 15),

            new Producto("ELEC-002", "Audífonos Sony WH-1000XM5",
                "Audífonos inalámbricos con cancelación de ruido activa de alta calidad",
                800_000.0, 1_049_900.0, "Audio", 30),

            new Producto("ELEC-003", "Laptop Lenovo IdeaPad 5",
                "Portátil 15.6 pulgadas, Intel Core i5, 16GB RAM, 512GB SSD",
                2_500_000.0, 3_099_900.0, "Computadores", 10)
        };

        for (Producto p : productosNuevos) {
            try {
                dao.crearProducto(p);
            } catch (IllegalArgumentException e) {
                System.err.println("[VALIDACIÓN] " + e.getMessage());
            } catch (SQLException e) {
                System.err.println("[SQL ERROR] " + e.getMessage());
            }
        }

        // Intento de crear con datos inválidos (precio de venta menor al base)
        System.out.println("\n→ Prueba con datos inválidos (precio venta < precio base):");
        try {
            Producto invalido = new Producto("ELEC-099", "Producto Test",
                "Descripción de prueba", 500_000.0, 300_000.0, "Prueba", 5);
            dao.crearProducto(invalido);
        } catch (IllegalArgumentException e) {
            System.err.println("[VALIDACIÓN CAPTURADA] " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("[SQL ERROR] " + e.getMessage());
        }

        // ── 2. READ ───────────────────────────────────────────────────────────
        System.out.println("\n═══ 2. BUSCAR POR CÓDIGO ═══");

        try {
            Producto encontrado = dao.buscarPorCodigo("ELEC-001");
            if (encontrado != null) {
                System.out.println("Producto encontrado: " + encontrado);
            }
        } catch (SQLException e) {
            System.err.println("[SQL ERROR] " + e.getMessage());
        }

        // Buscar código inexistente
        System.out.println("\n→ Buscar código inexistente (ELEC-999):");
        try {
            Producto noExiste = dao.buscarPorCodigo("ELEC-999");
            System.out.println(noExiste == null ? "Resultado: Producto no encontrado." : noExiste);
        } catch (SQLException e) {
            System.err.println("[SQL ERROR] " + e.getMessage());
        }

        // Listar todos los activos
        System.out.println("\n═══ 2b. LISTAR TODOS LOS PRODUCTOS ACTIVOS ═══");
        try {
            List<Producto> todos = dao.listarProductosActivos();
            todos.forEach(System.out::println);
        } catch (SQLException e) {
            System.err.println("[SQL ERROR] " + e.getMessage());
        }

        // ── 3. UPDATE ─────────────────────────────────────────────────────────
        System.out.println("\n═══ 3. ACTUALIZAR PRODUCTO ═══");

        try {
            Producto actualizado = new Producto(
                "ELEC-002",                                      // código NO cambia
                "Audífonos Sony WH-1000XM5 Edición Especial",   // nuevo nombre
                "Audífonos premium con cancelación activa de ruido, 40h batería y estuche incluido",
                820_000.0,   // precio base actualizado
                1_099_900.0, // precio venta actualizado
                "Audio",
                25           // stock actualizado
            );
            dao.actualizarProducto(actualizado);

            // Verificar la actualización
            Producto verificado = dao.buscarPorCodigo("ELEC-002");
            System.out.println("Datos después de actualizar: " + verificado);

        } catch (IllegalArgumentException e) {
            System.err.println("[VALIDACIÓN] " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("[SQL ERROR] " + e.getMessage());
        }

        // ── 4. DELETE LÓGICO ──────────────────────────────────────────────────
        System.out.println("\n═══ 4. ELIMINACIÓN LÓGICA ═══");

        try {
            dao.eliminarProducto("ELEC-003");

            // Confirmar que ya no aparece en consultas activas
            System.out.println("\n→ Verificando que ELEC-003 ya no es consultable:");
            Producto eliminado = dao.buscarPorCodigo("ELEC-003");
            System.out.println(eliminado == null
                ? "Correcto: ELEC-003 no aparece en consultas (sigue en BD como inactivo)."
                : "ALERTA: El producto aún aparece como activo.");

        } catch (IllegalArgumentException e) {
            System.err.println("[VALIDACIÓN] " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("[SQL ERROR] " + e.getMessage());
        }

        // ── Estado Final ───────────────────────────────────────────────────────
        System.out.println("\n═══ ESTADO FINAL DEL INVENTARIO ═══");
        try {
            List<Producto> activos = dao.listarProductosActivos();
            activos.forEach(System.out::println);
        } catch (SQLException e) {
            System.err.println("[SQL ERROR] " + e.getMessage());
        }

        // Cerrar la conexión al finalizar
        ConexionBD.cerrarConexion();
        System.out.println("\n[FIN] Demostración CRUD completada.");
    }
}
