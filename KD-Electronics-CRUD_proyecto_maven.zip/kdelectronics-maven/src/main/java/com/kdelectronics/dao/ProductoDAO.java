package com.kdelectronics.dao;

import com.kdelectronics.model.Producto;
import java.sql.SQLException;
import java.util.List;

/**
 * Interfaz DAO (Data Access Object) que define el contrato CRUD
 * para la entidad Producto.
 *
 * El uso de una interfaz permite:
 *  - Desacoplar la lógica de negocio del acceso a datos.
 *  - Facilitar pruebas unitarias con implementaciones mock.
 *  - Cambiar el proveedor de BD sin afectar el resto de la aplicación.
 *
 * @author [Nombre del Estudiante]
 * @version 1.0
 */
public interface ProductoDAO {

    /**
     * CREATE – Registra un nuevo producto en la base de datos.
     *
     * @param producto objeto Producto con todos sus datos
     * @throws SQLException          si ocurre un error de acceso a la BD
     * @throws IllegalArgumentException si los datos no superan la validación
     */
    void crearProducto(Producto producto) throws SQLException, IllegalArgumentException;

    /**
     * READ – Busca un producto activo por su código de producto.
     *
     * @param codigoProducto clave primaria del producto
     * @return Producto encontrado, o null si no existe / está inactivo
     * @throws SQLException si ocurre un error de acceso a la BD
     */
    Producto buscarPorCodigo(String codigoProducto) throws SQLException;

    /**
     * READ – Lista todos los productos activos en la base de datos.
     *
     * @return Lista de productos activos
     * @throws SQLException si ocurre un error de acceso a la BD
     */
    List<Producto> listarProductosActivos() throws SQLException;

    /**
     * UPDATE – Actualiza todos los campos del producto excepto el código.
     *
     * @param producto objeto con el código como identificador y los nuevos valores
     * @throws SQLException          si ocurre un error de acceso a la BD
     * @throws IllegalArgumentException si los datos no superan la validación
     */
    void actualizarProducto(Producto producto) throws SQLException, IllegalArgumentException;

    /**
     * DELETE LÓGICO – Desactiva el producto (activo = false).
     * No se elimina el registro físicamente de la base de datos.
     *
     * @param codigoProducto clave primaria del producto a desactivar
     * @throws SQLException si ocurre un error de acceso a la BD
     */
    void eliminarProducto(String codigoProducto) throws SQLException;
}
