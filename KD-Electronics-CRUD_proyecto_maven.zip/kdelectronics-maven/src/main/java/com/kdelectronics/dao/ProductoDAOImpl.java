package com.kdelectronics.dao;

import com.kdelectronics.db.ConexionBD;
import com.kdelectronics.model.Producto;
import com.kdelectronics.util.Validaciones;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementación concreta de ProductoDAO.
 * Contiene la lógica de acceso a datos mediante JDBC para el CRUD de Producto.
 *
 * Buenas prácticas implementadas:
 *  - PreparedStatement para prevenir inyección SQL.
 *  - Bloque try-with-resources para cerrar recursos automáticamente.
 *  - Manejo robusto de excepciones con mensajes descriptivos.
 *  - Validaciones previas a toda operación de escritura.
 *  - Eliminación lógica (soft delete) mediante campo 'activo'.
 *
 * @author [Nombre del Estudiante]
 * @version 1.0
 */
public class ProductoDAOImpl implements ProductoDAO {

    // ─── Sentencias SQL ───────────────────────────────────────────────────────

    private static final String SQL_CREAR =
        "INSERT INTO productos (codigo_producto, nombre, descripcion, " +
        "precio_base, precio_venta, categoria, cantidad_disponible, activo) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?, 1)";

    private static final String SQL_BUSCAR_POR_CODIGO =
        "SELECT * FROM productos WHERE codigo_producto = ? AND activo = 1";

    private static final String SQL_LISTAR_ACTIVOS =
        "SELECT * FROM productos WHERE activo = 1 ORDER BY codigo_producto";

    private static final String SQL_ACTUALIZAR =
        "UPDATE productos SET nombre = ?, descripcion = ?, precio_base = ?, " +
        "precio_venta = ?, categoria = ?, cantidad_disponible = ? " +
        "WHERE codigo_producto = ? AND activo = 1";

    private static final String SQL_ELIMINAR_LOGICO =
        "UPDATE productos SET activo = 0 WHERE codigo_producto = ?";

    // ─── CREATE ───────────────────────────────────────────────────────────────

    @Override
    public void crearProducto(Producto producto) throws SQLException, IllegalArgumentException {

        // 1. Validar datos antes de acceder a la BD
        Validaciones.validarProductoCompleto(producto);

        // 2. Verificar que el código no exista ya (incluso inactivo)
        if (existeCodigoEnBD(producto.getCodigoProducto())) {
            throw new IllegalArgumentException(
                "Ya existe un producto con el código '" + producto.getCodigoProducto() +
                "'. El código de producto debe ser único."
            );
        }

        // 3. Insertar usando PreparedStatement (evita inyección SQL)
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(SQL_CREAR)) {

            ps.setString(1, producto.getCodigoProducto().trim());
            ps.setString(2, producto.getNombre().trim());
            ps.setString(3, producto.getDescripcion().trim());
            ps.setDouble(4, producto.getPrecioBase());
            ps.setDouble(5, producto.getPrecioVenta());
            ps.setString(6, producto.getCategoria().trim());
            ps.setInt   (7, producto.getCantidadDisponible());

            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("[CREATE] Producto '" + producto.getCodigoProducto()
                    + "' registrado exitosamente.");
            } else {
                throw new SQLException("No se pudo insertar el producto. Intente de nuevo.");
            }
        }
    }

    // ─── READ: Buscar por Código ──────────────────────────────────────────────

    @Override
    public Producto buscarPorCodigo(String codigoProducto) throws SQLException {

        if (!Validaciones.validarCodigo(codigoProducto)) {
            throw new IllegalArgumentException(
                "El código '" + codigoProducto + "' tiene un formato inválido."
            );
        }

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(SQL_BUSCAR_POR_CODIGO)) {

            ps.setString(1, codigoProducto.trim());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return mapearResultSet(rs);
            } else {
                System.out.println("[READ] No se encontró un producto activo con código: "
                    + codigoProducto);
                return null;
            }
        }
    }

    // ─── READ: Listar Todos los Activos ──────────────────────────────────────

    @Override
    public List<Producto> listarProductosActivos() throws SQLException {
        List<Producto> lista = new ArrayList<>();

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(SQL_LISTAR_ACTIVOS);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearResultSet(rs));
            }
            System.out.println("[READ] Total productos activos encontrados: " + lista.size());
        }
        return lista;
    }

    // ─── UPDATE ───────────────────────────────────────────────────────────────

    @Override
    public void actualizarProducto(Producto producto) throws SQLException, IllegalArgumentException {

        // Validar todos los campos (el código se usa como identificador, no se actualiza)
        Validaciones.validarProductoCompleto(producto);

        // Verificar que el producto exista y esté activo
        if (buscarPorCodigo(producto.getCodigoProducto()) == null) {
            throw new IllegalArgumentException(
                "No existe un producto activo con código '" + producto.getCodigoProducto() +
                "'. No se puede actualizar."
            );
        }

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(SQL_ACTUALIZAR)) {

            ps.setString(1, producto.getNombre().trim());
            ps.setString(2, producto.getDescripcion().trim());
            ps.setDouble(3, producto.getPrecioBase());
            ps.setDouble(4, producto.getPrecioVenta());
            ps.setString(5, producto.getCategoria().trim());
            ps.setInt   (6, producto.getCantidadDisponible());
            ps.setString(7, producto.getCodigoProducto().trim()); // WHERE

            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("[UPDATE] Producto '" + producto.getCodigoProducto()
                    + "' actualizado exitosamente.");
            } else {
                throw new SQLException("No se pudo actualizar el producto. Intente de nuevo.");
            }
        }
    }

    // ─── DELETE LÓGICO ───────────────────────────────────────────────────────

    @Override
    public void eliminarProducto(String codigoProducto) throws SQLException {

        if (!Validaciones.validarCodigo(codigoProducto)) {
            throw new IllegalArgumentException(
                "Código inválido: '" + codigoProducto + "'."
            );
        }

        // Verificar que el producto exista y esté activo antes de eliminar
        if (buscarPorCodigo(codigoProducto) == null) {
            throw new IllegalArgumentException(
                "No existe un producto activo con código '" + codigoProducto +
                "'. No se puede desactivar."
            );
        }

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(SQL_ELIMINAR_LOGICO)) {

            ps.setString(1, codigoProducto.trim());
            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("[DELETE LÓGICO] Producto '" + codigoProducto
                    + "' desactivado (no eliminado físicamente).");
            } else {
                throw new SQLException("No se pudo desactivar el producto. Intente de nuevo.");
            }
        }
    }

    // ─── Métodos Privados Auxiliares ──────────────────────────────────────────

    /**
     * Mapea una fila del ResultSet a un objeto Producto.
     *
     * @param rs ResultSet posicionado en la fila a leer
     * @return Producto construido con los datos del ResultSet
     * @throws SQLException si ocurre un error al leer columnas
     */
    private Producto mapearResultSet(ResultSet rs) throws SQLException {
        Producto p = new Producto();
        p.setCodigoProducto  (rs.getString("codigo_producto"));
        p.setNombre          (rs.getString("nombre"));
        p.setDescripcion     (rs.getString("descripcion"));
        p.setPrecioBase      (rs.getDouble("precio_base"));
        p.setPrecioVenta     (rs.getDouble("precio_venta"));
        p.setCategoria       (rs.getString("categoria"));
        p.setCantidadDisponible(rs.getInt("cantidad_disponible"));
        p.setActivo          (rs.getBoolean("activo"));
        return p;
    }

    /**
     * Verifica si un código de producto ya existe en la BD (activo o no).
     *
     * @param codigo código a verificar
     * @return true si existe algún registro con ese código
     * @throws SQLException si ocurre un error de acceso a la BD
     */
    private boolean existeCodigoEnBD(String codigo) throws SQLException {
        String sql = "SELECT COUNT(*) FROM productos WHERE codigo_producto = ?";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, codigo.trim());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }
}
