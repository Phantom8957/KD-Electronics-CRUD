package com.kdelectronics.model;

/**
 * Clase de dominio que representa un Producto en el inventario de KD-Electronics.
 * Implementa encapsulamiento mediante atributos privados y métodos getter/setter.
 *
 * @author [Nombre del Estudiante]
 * @version 1.0
 */
public class Producto {

    // Atributos del producto (campos de la tabla)
    private String codigoProducto;    // PK - no modificable
    private String nombre;
    private String descripcion;
    private double precioBase;
    private double precioVenta;
    private String categoria;
    private int cantidadDisponible;
    private boolean activo;            // Para la eliminación lógica (soft delete)

    // ─── Constructores ────────────────────────────────────────────────────────

    /** Constructor vacío requerido por JDBC al mapear ResultSet */
    public Producto() {
        this.activo = true;
    }

    /**
     * Constructor completo para crear un nuevo producto.
     *
     * @param codigoProducto  Código único del producto
     * @param nombre          Nombre del producto
     * @param descripcion     Descripción detallada
     * @param precioBase      Precio de costo / base
     * @param precioVenta     Precio de venta al público
     * @param categoria       Categoría del producto (ej. "Smartphones")
     * @param cantidadDisponible Unidades en inventario
     */
    public Producto(String codigoProducto, String nombre, String descripcion,
                    double precioBase, double precioVenta,
                    String categoria, int cantidadDisponible) {
        this.codigoProducto   = codigoProducto;
        this.nombre           = nombre;
        this.descripcion      = descripcion;
        this.precioBase       = precioBase;
        this.precioVenta      = precioVenta;
        this.categoria        = categoria;
        this.cantidadDisponible = cantidadDisponible;
        this.activo           = true;
    }

    // ─── Getters & Setters ────────────────────────────────────────────────────

    public String getCodigoProducto() { return codigoProducto; }
    public void setCodigoProducto(String codigoProducto) { this.codigoProducto = codigoProducto; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public double getPrecioBase() { return precioBase; }
    public void setPrecioBase(double precioBase) { this.precioBase = precioBase; }

    public double getPrecioVenta() { return precioVenta; }
    public void setPrecioVenta(double precioVenta) { this.precioVenta = precioVenta; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public int getCantidadDisponible() { return cantidadDisponible; }
    public void setCantidadDisponible(int cantidadDisponible) { this.cantidadDisponible = cantidadDisponible; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    // ─── toString ─────────────────────────────────────────────────────────────

    @Override
    public String toString() {
        return  "\n╔══════════════════════════════════════════════╗" +
                "\n  PRODUCTO: " + codigoProducto +
                "\n  Nombre   : " + nombre +
                "\n  Descripción: " + descripcion +
                "\n  Precio Base : $" + String.format("%.2f", precioBase) +
                "\n  Precio Venta: $" + String.format("%.2f", precioVenta) +
                "\n  Categoría : " + categoria +
                "\n  Cantidad  : " + cantidadDisponible + " unidades" +
                "\n  Estado    : " + (activo ? "ACTIVO" : "INACTIVO") +
                "\n╚══════════════════════════════════════════════╝";
    }
}
