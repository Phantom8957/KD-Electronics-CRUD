package com.kdelectronics.util;

import com.kdelectronics.model.Producto;
import java.util.regex.Pattern;

/**
 * Clase utilitaria con validaciones de datos usando expresiones regulares (Regex).
 *
 * Las expresiones regulares permiten definir reglas precisas sobre el formato
 * esperado de cada campo, detectando datos inválidos antes de persistirlos
 * en la base de datos.
 *
 * @author [Nombre del Estudiante]
 * @version 1.0
 */
public class Validaciones {

    // ─── Expresiones Regulares ────────────────────────────────────────────────

    /**
     * Código de producto: letras mayúsculas/minúsculas, dígitos y guiones.
     * Longitud: 3 a 20 caracteres.
     * Ejemplos válidos: "ELEC-001", "TV2024", "PROD-1A"
     */
    private static final Pattern PATRON_CODIGO =
            Pattern.compile("^[A-Za-z0-9\\-]{3,20}$");

    /**
     * Nombre: letras (incluyendo acentos y ñ), espacios, guiones y apóstrofes.
     * Longitud: 2 a 100 caracteres.
     * Ejemplos válidos: "Televisor Samsung 55\"", "Audífonos Inalámbricos"
     */
    private static final Pattern PATRON_NOMBRE =
            Pattern.compile("^[A-Za-zÁÉÍÓÚáéíóúÑñÜü0-9 \\-'\",.]{2,100}$");

    /**
     * Categoría: solo letras (con acentos), espacios y guiones.
     * Longitud: 2 a 50 caracteres.
     * Ejemplos válidos: "Smartphones", "Audio y Video", "Accesorios"
     */
    private static final Pattern PATRON_CATEGORIA =
            Pattern.compile("^[A-Za-zÁÉÍÓÚáéíóúÑñ \\-]{2,50}$");

    // ─── Métodos de Validación Individual ────────────────────────────────────

    /**
     * Valida el código del producto con expresión regular.
     *
     * @param codigo código a validar
     * @return true si es válido
     */
    public static boolean validarCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) return false;
        return PATRON_CODIGO.matcher(codigo.trim()).matches();
    }

    /**
     * Valida el nombre del producto con expresión regular.
     *
     * @param nombre nombre a validar
     * @return true si es válido
     */
    public static boolean validarNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) return false;
        return PATRON_NOMBRE.matcher(nombre.trim()).matches();
    }

    /**
     * Valida que el precio sea estrictamente positivo.
     *
     * @param precio precio a validar
     * @return true si precio > 0
     */
    public static boolean validarPrecio(double precio) {
        return precio > 0.0;
    }

    /**
     * Valida que la cantidad disponible no sea negativa.
     *
     * @param cantidad cantidad a validar
     * @return true si cantidad >= 0
     */
    public static boolean validarCantidad(int cantidad) {
        return cantidad >= 0;
    }

    /**
     * Valida la categoría del producto con expresión regular.
     *
     * @param categoria categoría a validar
     * @return true si es válida
     */
    public static boolean validarCategoria(String categoria) {
        if (categoria == null || categoria.trim().isEmpty()) return false;
        return PATRON_CATEGORIA.matcher(categoria.trim()).matches();
    }

    // ─── Validación Completa del Producto ─────────────────────────────────────

    /**
     * Valida todos los campos de un Producto de forma integral.
     * Lanza IllegalArgumentException con mensaje descriptivo ante el primer
     * campo inválido encontrado.
     *
     * @param producto objeto Producto a validar
     * @throws IllegalArgumentException si algún campo no cumple las reglas
     */
    public static void validarProductoCompleto(Producto producto)
            throws IllegalArgumentException {

        if (!validarCodigo(producto.getCodigoProducto())) {
            throw new IllegalArgumentException(
                "Código de producto inválido '" + producto.getCodigoProducto() +
                "'. Use letras, números y guiones (3-20 caracteres). Ej: ELEC-001"
            );
        }
        if (!validarNombre(producto.getNombre())) {
            throw new IllegalArgumentException(
                "Nombre de producto inválido '" + producto.getNombre() +
                "'. Solo letras, números, espacios y signos básicos (2-100 chars)."
            );
        }
        if (producto.getDescripcion() == null || producto.getDescripcion().trim().isEmpty()) {
            throw new IllegalArgumentException(
                "La descripción del producto no puede estar vacía."
            );
        }
        if (!validarPrecio(producto.getPrecioBase())) {
            throw new IllegalArgumentException(
                "El precio base debe ser mayor a $0. Valor recibido: " + producto.getPrecioBase()
            );
        }
        if (!validarPrecio(producto.getPrecioVenta())) {
            throw new IllegalArgumentException(
                "El precio de venta debe ser mayor a $0. Valor recibido: " + producto.getPrecioVenta()
            );
        }
        if (producto.getPrecioVenta() < producto.getPrecioBase()) {
            throw new IllegalArgumentException(
                "El precio de venta ($" + producto.getPrecioVenta() +
                ") no puede ser menor al precio base ($" + producto.getPrecioBase() + ")."
            );
        }
        if (!validarCantidad(producto.getCantidadDisponible())) {
            throw new IllegalArgumentException(
                "La cantidad disponible no puede ser negativa. Valor recibido: "
                + producto.getCantidadDisponible()
            );
        }
        if (!validarCategoria(producto.getCategoria())) {
            throw new IllegalArgumentException(
                "Categoría inválida '" + producto.getCategoria() +
                "'. Solo letras y espacios (2-50 caracteres). Ej: Smartphones"
            );
        }
    }
}
