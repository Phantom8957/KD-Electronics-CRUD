package com.kdelectronics.db;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Gestiona la conexión JDBC leyendo los parámetros desde config.properties.
 * Para cambiar usuario o contraseña solo edita src/main/resources/config.properties,
 * sin tocar el código Java.
 *
 * @author [Nombre del Estudiante]
 */
public class ConexionBD {

    private static Connection conexion = null;
    private static Properties props    = null;

    private ConexionBD() {}

    /** Carga config.properties una sola vez. */
    private static void cargarPropiedades() throws SQLException {
        if (props != null) return;
        props = new Properties();
        try (InputStream in = ConexionBD.class
                .getClassLoader()
                .getResourceAsStream("config.properties")) {

            if (in == null) {
                throw new SQLException(
                    "No se encontró config.properties en src/main/resources/");
            }
            props.load(in);
        } catch (IOException e) {
            throw new SQLException("Error al leer config.properties: " + e.getMessage());
        }
    }

    /**
     * Retorna una conexión activa. Si no existe o fue cerrada, la crea.
     *
     * @return Connection JDBC a MySQL
     * @throws SQLException si falla la conexión
     */
    public static Connection obtenerConexion() throws SQLException {
        cargarPropiedades();
        try {
            if (conexion == null || conexion.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conexion = DriverManager.getConnection(
                    props.getProperty("db.url"),
                    props.getProperty("db.usuario"),
                    props.getProperty("db.clave")
                );
                System.out.println("[DB] Conexión establecida con KD-Electronics.");
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver MySQL no encontrado: " + e.getMessage());
        }
        return conexion;
    }

    /** Cierra la conexión activa. */
    public static void cerrarConexion() {
        if (conexion != null) {
            try {
                conexion.close();
                conexion = null;
                System.out.println("[DB] Conexión cerrada correctamente.");
            } catch (SQLException e) {
                System.err.println("[ERROR] Al cerrar conexión: " + e.getMessage());
            }
        }
    }
}
