-- ═══════════════════════════════════════════════════════════════
--  Script SQL - Sistema de Inventario KD-Electronics
--  Base de datos: kdelectronics
--  Motor: MySQL 8.x
-- ═══════════════════════════════════════════════════════════════

-- 1. Crear la base de datos (si no existe)
CREATE DATABASE IF NOT EXISTS kdelectronics
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE kdelectronics;

-- 2. Crear la tabla de productos
CREATE TABLE IF NOT EXISTS productos (
    codigo_producto      VARCHAR(20)     NOT NULL,
    nombre               VARCHAR(100)    NOT NULL,
    descripcion          TEXT            NOT NULL,
    precio_base          DECIMAL(12, 2)  NOT NULL CHECK (precio_base > 0),
    precio_venta         DECIMAL(12, 2)  NOT NULL CHECK (precio_venta > 0),
    categoria            VARCHAR(50)     NOT NULL,
    cantidad_disponible  INT             NOT NULL DEFAULT 0 CHECK (cantidad_disponible >= 0),
    activo               TINYINT(1)      NOT NULL DEFAULT 1,  -- 1=activo, 0=eliminado lógicamente
    fecha_registro       TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT pk_producto PRIMARY KEY (codigo_producto)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Índice para mejorar consultas por estado activo
CREATE INDEX idx_activo ON productos (activo);

-- 4. Datos de prueba iniciales
INSERT INTO productos
    (codigo_producto, nombre, descripcion, precio_base, precio_venta, categoria, cantidad_disponible, activo)
VALUES
    ('ELEC-001', 'Smart TV Samsung 55"',
     'Televisor QLED 55 pulgadas 4K Ultra HD con Smart TV integrado',
     1200000.00, 1599900.00, 'Televisores', 15, 1),

    ('ELEC-002', 'Audífonos Sony WH-1000XM5',
     'Audífonos inalámbricos con cancelación de ruido activa de alta calidad',
     800000.00, 1049900.00, 'Audio', 30, 1),

    ('ELEC-003', 'Laptop Lenovo IdeaPad 5',
     'Portátil 15.6 pulgadas, Intel Core i5, 16GB RAM, 512GB SSD',
     2500000.00, 3099900.00, 'Computadores', 10, 1),

    ('ELEC-004', 'iPhone 15 Pro',
     'Smartphone Apple con chip A17 Pro, cámara de 48MP y pantalla Super Retina XDR',
     4800000.00, 5999900.00, 'Smartphones', 20, 1),

    ('ELEC-005', 'Tablet Samsung Galaxy Tab S9',
     'Tablet Android 11 pulgadas, 8GB RAM, 256GB almacenamiento, con S-Pen incluido',
     1900000.00, 2399900.00, 'Tablets', 12, 1);

-- 5. Verificación: mostrar los productos insertados
SELECT
    codigo_producto     AS 'Código',
    nombre              AS 'Nombre',
    precio_venta        AS 'Precio Venta',
    categoria           AS 'Categoría',
    cantidad_disponible AS 'Stock',
    IF(activo = 1, 'ACTIVO', 'INACTIVO') AS 'Estado'
FROM productos
ORDER BY codigo_producto;
